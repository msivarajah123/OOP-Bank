package project;

public class Gold extends setState{
    @Override
    public String toString() {
        return("Gold");
    }
}
