package project;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import static project.OwnersCustomersScreen.Customers;

//User Events
// Interacting Buttons 
public class Login extends Application {

    static Scene loginScene; //JavaFX
    static Button loginButton;
    static Stage window;
    static Label name, password, welcome;
    static TextField input;
    static PasswordField pass;
    static GridPane grid;
    static final String file = "customers.txt"; //File name

    public void gridLayout() {
        grid = new GridPane(); //Edges against window
        grid.setPadding(new Insets(20, 20, 20, 20)); // 4 values: amount of padding for each edge
        grid.setVgap(8); //Vertical Spacing
        grid.setHgap(10); // Horizontal Spacing

    }

    public void userName() {//Sets username input textfield + label
        name = new Label("Username:");
        GridPane.setConstraints(name, 0, 1); // Place: The Label name
        input = new TextField();
        GridPane.setConstraints(input, 1, 1); // Place TextField input
    }

    public void passWord() {//Sets password input textfield + label
        password = new Label("Password:");
        GridPane.setConstraints(password, 0, 2); // Place label Password
        pass = new PasswordField();
        GridPane.setConstraints(pass, 1, 2); // Place TextField PassWord
    }

    public void createLoginButton(OwnerStartScreen screen, CustomerStartScreen cscreen){
        loginButton = new Button("Login"); // Login Button  
        GridPane.setConstraints(loginButton, 1, 3); // Location of Button    
        // Action Button with Validity
        loginButton.setOnAction(e -> {
            if (input.getText().equals("admin") && pass.getText().equals("admin")) {
                try { 
                    screen.start(window);
                } catch (Exception ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }
                window.setScene(screen.ownerStartScene);
            } else {
                //Checks for if a customer logged in
                try {
                    FileReader reader = new FileReader(file);
                    BufferedReader buff = new BufferedReader(reader);

                    String line = null;
                    String user = null;
                    String password = null;
                    int count = 0;
                    while ((line = buff.readLine()) != null) {
                        if (count == 2) {
                            if (input.getText().equals(user) && pass.getText().equals(password)) {
                                try {
                                    screen.start(window);
                                } catch (Exception ex) {
                                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                for (int i = 0; i < Customers.size(); i++) { // For loop finds the Customer Object in ArrayList
                                    if (Customers.get(i).getUser().equals(input.getText()) && Customers.get(i).getPass().equals(pass.getText())) {                                       
                                            
                                        try {
                                            cscreen.start(window,Customers.get(i)); // Customer Object to access setters and getters
                                        } catch (Exception ex) {
                                            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                                        }
                                       
                                        break;
                                    }
                                }
                                window.setScene(cscreen.customerStartScene); //Help!?

                            }
                            count = 0;
                        } else if (count == 1) {
                            password = line;
                            count++;
                        } else {
                            count++;
                            user = line;
                        }
                    }

                    buff.close();
                } catch (IOException er) {
                    //do nothing
                }
                input.setText("");
                pass.setText("");
            }
        });

    }

    public void start(Stage loginStage) throws Exception {
        window = loginStage;
        OwnerStartScreen ownerStart = new OwnerStartScreen(); // DO NOT CHANGE
        CustomerStartScreen customerStart = new CustomerStartScreen(); // DO NOT CHANGE
        loginStage.setTitle("BookStore App");
         //ownerStart.start(loginStage); // Next Screen
        //customerStart.start(window); //Next Screen

        gridLayout();

        // Set Welcome Message
        welcome = new Label("Welcome to the BookStore App");
        GridPane.setConstraints(welcome, 0, 0);

        userName();
        passWord();
        createLoginButton(ownerStart, customerStart);

        grid.getChildren().addAll(welcome, name, input, password, pass, loginButton); // Add to Grid
        loginScene = new Scene(grid, 500, 250); // Intializing Scene    

        window.setScene(loginScene); // Adding Scene on Stage (Initial)     
        window.show(); // Display
    }

}
