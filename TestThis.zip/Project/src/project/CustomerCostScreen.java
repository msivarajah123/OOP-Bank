/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
/**
 *
 * @author clank
 */
public class CustomerCostScreen extends CustomerStartScreen {
    static Scene customerCostScene; //JavaFX
    static Button logout;
    static Label TotalCost;
    static Label Points_Status;
    VBox VboxFinal = new VBox();
    
    static double Bookprice; //Used Variables
    static int Points;
    static String status;
    static Set state = new Set();
    static String stringStatus;
    
    public void setUp(){//Sets up total cost, points/status and the logout button
        TotalCost = new Label("Total cost of books is: $" + Bookprice);
        stringStatus = state.getState().toString();
        Points_Status = new Label("Number of points in account is: " + Points + ". Your current status is: " + stringStatus);
        
        createFinalButton();
        VboxFinal.getChildren().addAll(TotalCost, Points_Status, logout);
    }
    
     public void createFinalButton() {//Creates logout button
        VboxFinal = new VBox();
        logout = new Button("Logout");
        logout.setOnAction(e -> {
            input.setText("");
            pass.setText("");

            window.setScene(loginScene);
        });  // Action on Button Scene change
    }
    
    
    
    public void start(Stage customerCostStage) throws Exception {
        setUp();
        gridLayout(); //Sets up the Grid Layout  

        
       grid.getChildren().add(VboxFinal);
       customerCostScene = new Scene(grid, 500, 500); // Intializing Scene    


    }
    
    
    
}
