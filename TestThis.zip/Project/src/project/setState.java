package project;

public abstract class setState {
    public abstract String toString();
}