package project;

//JavaFX imports
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import static project.Login.grid;
import static project.OwnersCustomersScreen.backToOwner;
// Reading/Writing imports
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class OwnersCustomersScreen extends OwnerStartScreen {
    
    static Scene ownerCustomerScene; //JavaFX
    static Button backToOwner;
    static Button add = new Button("Add");
    static Button delete = new Button("Delete");
    static TextField userIn, passIn;
    static TableView<Customer> opentable; //Table GUI
    static ObservableList<Customer> Customers; //Customer ArrayList Tracker

    static final String file = "customers.txt"; //Main txt file
    
    HBox hbox = new HBox(); //Design formatters
    HBox hbox2 = new HBox();
    VBox vbox = new VBox();
    
    public void createBackButton() {
        backToOwner = new Button ("Back");
        backToOwner.setOnAction(e -> {// Will write to the file if you move back
            try{
                FileWriter write = new FileWriter(file);
                BufferedWriter buff = new BufferedWriter(write);
                for (int x = 0; x < opentable.getItems().size(); x++){
                    buff.write(opentable.getItems().get(x).getUser());
                    buff.newLine();
                    buff.write(opentable.getItems().get(x).getPass());
                    buff.newLine();
                    buff.write(Integer.toString(opentable.getItems().get(x).getPoints()));
                    buff.newLine();
                }
                buff.close();
            } catch (IOException er){
                //do nothing
            }
            window.setScene(ownerStartScene);
            });
        GridPane.setConstraints(backToOwner, 5, 8); // Location of Button
    }
    
    public ObservableList<Customer> getCustomers(){ //Generates list of customers from file to be inserted into the table
        Customers = FXCollections.observableArrayList();
        try{
            FileReader reader = new FileReader(file);
            BufferedReader buff = new BufferedReader(reader);
            
            String line = null;
            String user = null;
            String pass = null;
            int count = 0;
            while ((line = buff.readLine())!= null){
                if (count == 2){
                    count = 0;
                    Customers.add(new Customer(user,pass,Integer.parseInt(line)));
                }
                else if (count == 1){
                    pass = line;
                    count++;
                }
                else{
                    count++;
                    user = line;
                }
            }
            
            buff.close();
        } catch (IOException e){
            //do nothing
        }
        
        return Customers;
    }
    
    public void createCustomerTable(){ //Formats the design of the table
        //Username Column
        TableColumn<Customer, String> userColumn = new TableColumn<>("Username");
        userColumn.setMinWidth(125);
        userColumn.setCellValueFactory(new PropertyValueFactory<>("user"));
        
        //Password Column
        TableColumn<Customer, String> passColumn = new TableColumn<>("Password");
        passColumn.setMinWidth(125);
        passColumn.setCellValueFactory(new PropertyValueFactory<>("pass"));
        
        //Points Column
        TableColumn<Customer, Integer> pointColumn = new TableColumn<>("Points");
        pointColumn.setMinWidth(50);
        pointColumn.setCellValueFactory(new PropertyValueFactory<>("points"));
        
        //Builds Table
        opentable = new TableView(); //Table Format
        opentable.setItems(getCustomers()); //Grabs customers from generated arraylist
        opentable.getColumns().addAll(userColumn, passColumn, pointColumn); //Adds to table
    }
    
    public void createCustomerOptions(){//Deals with add/delete functions, generates the entire book GUI
        userIn = new TextField();//GUIs
        passIn = new TextField();
        
        userIn.setPromptText("Username");//Formatters
        userIn.setMinWidth(50);
        
        passIn.setPromptText("Password");
        passIn.setMinWidth(50);
        
        hbox.setPadding(new Insets(10,10,10,10));
        hbox.setSpacing(10);
        
        hbox2.setPadding(new Insets(10,10,10,10));
        hbox2.setSpacing(265);
        
        add.setOnAction(e -> {//Add function command
            Customer newCustomer = new Customer(" ", " ", 0);
            newCustomer.setUser(userIn.getText());
            newCustomer.setPass(passIn.getText());
            newCustomer.setPoints(0);
            
            if ((userIn.getText().equals("")) || (passIn.getText().equals(""))){ //Empty check
                
            }
            else{
                opentable.getItems().add(newCustomer);
            }
            
            userIn.clear();
            passIn.clear();
            window.setOnCloseRequest(er -> close()); //Sets exit button to save if things are added
        });
        
        delete.setOnAction(e -> { //Delete function command
            ObservableList<Customer> selected, items;
            items = opentable.getItems(); //Takes all items from table
            selected = opentable.getSelectionModel().getSelectedItems(); //Takes the one which are selected
            
            selected.forEach(items::remove); //Removes all selected items
            window.setOnCloseRequest(er -> close()); //Sets exit button to save if things are deleted
        });
        
        //Builds the entire interface
        hbox.getChildren().addAll(userIn, passIn, add);
        hbox2.getChildren().addAll(delete, backToOwner);
        vbox.getChildren().addAll(opentable, hbox, hbox2);
    }
    
    protected void close() { //Saves if exit button is pressed
        try{
            FileWriter write = new FileWriter(file);
            BufferedWriter buff = new BufferedWriter(write);
            for (int x = 0; x < opentable.getItems().size(); x++){
                buff.write(opentable.getItems().get(x).getUser());
                buff.newLine();
                buff.write(opentable.getItems().get(x).getPass());
                buff.newLine();
                buff.write(Integer.toString(opentable.getItems().get(x).getPoints()));
                buff.newLine();
            }
            buff.close();
            } catch (IOException er){
                //do nothing
            }
        window.close();
    }
    public void start(Stage ownerCustomerStage) throws Exception {
        gridLayout(); //Sets up the Grid Layout  
        createBackButton();
        createCustomerTable();
        createCustomerOptions();
        grid.getChildren().add(vbox);
        ownerCustomerScene = new Scene(grid, 420, 500);
 
    }

}
