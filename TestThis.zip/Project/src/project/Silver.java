package project;

public class Silver extends setState{
    @Override
    public String toString() {
        return("Silver");
    }
}
